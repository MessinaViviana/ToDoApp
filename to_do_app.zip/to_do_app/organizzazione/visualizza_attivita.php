<?php
// Connessione al database
include('db.php');

// Recupera l'ID del progetto dalla query string
$id_progetto = $_GET['id_progetto'] ?? 0;

// Recupera le informazioni del progetto
$query_progetto = "SELECT * FROM progetti WHERE id = '$id_progetto'";
$result_progetto = mysqli_query($conn, $query_progetto);
$progetto = mysqli_fetch_assoc($result_progetto);

// Recupera le attività associate al progetto
$query_attivita = "SELECT * FROM attivita WHERE id_progetto = '$id_progetto'";
$result_attivita = mysqli_query($conn, $query_attivita);

// Chiudi la connessione al database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attività del Progetto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: left;
        }

        table th {
            background-color: rgba(0, 0, 0, 0.5);
            text-transform: uppercase;
        }

        table tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        table tr:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .button {
            padding: 8px 12px;
            margin: 0 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            color: #fff;
            display: inline-block; /* Aggiungi inline-block */
            width: auto; /* Impostiamo la larghezza automatica */
        }

        .button:not(:last-child) {
            margin-right: 10px; /* Aggiungi margine tra i pulsanti */
        }

        .edit-button {
            background-color: #ffc107;
        }

        .delete-button {
            background-color: #dc3545;
        }

        .back-button {
            display: inline-block;
            background-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
        }

        .back-button:hover,
        .button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Attività del Progetto</h1>

    <!-- Mostra il nome del progetto -->
    <?php if ($progetto): ?>
        <h2><?php echo htmlspecialchars($progetto['nome']); ?></h2>
        <p><?php echo htmlspecialchars($progetto['descrizione']); ?></p>
    <?php else: ?>
        <p>Progetto non trovato.</p>
        <a href="index.php" class="back-button">Torna alla lista dei progetti</a>
        <?php exit; ?>
    <?php endif; ?>

    <!-- Tabella delle attività -->
    <?php if (mysqli_num_rows($result_attivita) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Titolo</th>
                    <th>Descrizione</th>
                    <th>Data Scadenza</th>
                    <th>Completato</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($attivita = mysqli_fetch_assoc($result_attivita)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($attivita['titolo']); ?></td>
                        <td><?php echo htmlspecialchars($attivita['descrizione']); ?></td>
                        <td><?php echo htmlspecialchars($attivita['data_scadenza']); ?></td>
                        <td><?php echo $attivita['completato'] ? 'Sì' : 'No'; ?></td>
                        <td>
                            <!-- Pulsanti per modificare o eliminare attività -->
                            <a href="modifica_attivita.php?id_attivita=<?php echo $attivita['id']; ?>" class="button edit-button">Modifica</a>
                            <a href="elimina_attivita.php?id_attivita=<?php echo $attivita['id']; ?>" class="button delete-button" onclick="return confirm('Sei sicuro di voler eliminare questa attività?')">Elimina</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nessuna attività trovata per questo progetto.</p>
    <?php endif; ?>

    <a href="index.php" class="back-button">Torna alla lista dei progetti</a>
</div>

</body>
</html>
