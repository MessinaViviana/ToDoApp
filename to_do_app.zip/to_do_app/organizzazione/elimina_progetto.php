<?php
// Connessione al database
include('db.php');

// Recupera l'ID del progetto dalla query string
$id_progetto = $_GET['id_progetto'] ?? 0;

// Se non è stato passato un ID valido, reindirizza alla lista dei progetti
if (!$id_progetto) {
    header('Location: index.php');
    exit;
}

// Elimina il progetto dal database
$query_delete = "DELETE FROM progetti WHERE id = '$id_progetto'";
mysqli_query($conn, $query_delete);

// Chiudi la connessione al database
mysqli_close($conn);

// Reindirizza alla lista dei progetti
header('Location: index.php');
exit;
?>
