<?php
// Connessione al database
include('db.php');

// Recupera l'ID dell'attività dalla query string
$id_attivita = $_GET['id_attivita'] ?? 0;

// Recupera l'ID del progetto associato
$id_progetto = $_GET['id_progetto'] ?? 0;

// Elimina l'attività dal database
$query_elimina = "DELETE FROM attivita WHERE id = '$id_attivita'";

if (mysqli_query($conn, $query_elimina)) {
    // Redirige alla pagina delle attività del progetto
    header('Location: visualizza_attivita.php?id_progetto=' . $id_progetto);
    exit;
} else {
    echo "Errore nell'eliminazione dell'attività: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
