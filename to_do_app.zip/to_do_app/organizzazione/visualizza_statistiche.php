<?php
// Connessione al database
include('db.php');

// Query per ottenere le statistiche
$query = "
    SELECT 
        (SELECT COUNT(*) FROM progetti) AS total_progetti,
        (SELECT COUNT(*) FROM attivita) AS total_attivita,
        (SELECT COUNT(*) FROM attivita WHERE completato = 1) AS total_attivita_completate,
        (SELECT COUNT(*) FROM attivita WHERE completato = 0) AS total_attivita_non_completate;
";
$result = mysqli_query($conn, $query);
$statistics = mysqli_fetch_assoc($result);

// Chiudi la connessione al database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiche</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .stat {
            margin: 15px 0;
        }

        .back-button {
            display: inline-block;
            background-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            text-align: center;
        }

        .back-button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Statistiche</h1>

        <div class="stat">
            <strong>Numero di Progetti:</strong> <?php echo $statistics['total_progetti']; ?>
        </div>
        <div class="stat">
            <strong>Numero di Attività:</strong> <?php echo $statistics['total_attivita']; ?>
        </div>
        <div class="stat">
            <strong>Attività Completate:</strong> <?php echo $statistics['total_attivita_completate']; ?>
        </div>
        <div class="stat">
            <strong>Attività Non Completate:</strong> <?php echo $statistics['total_attivita_non_completate']; ?>
        </div>

        <a href="index.html" class="back-button">Torna alla pagina principale</a>
    </div>
</body>
</html>
