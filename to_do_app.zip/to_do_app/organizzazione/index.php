<?php
// Connessione al database
include('db.php');

// Recupera tutti i progetti dal database
$query = "SELECT * FROM progetti";
$result = mysqli_query($conn, $query);
$projects = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Chiudi la connessione al database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestione Progetti</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: left;
        }

        table th {
            background-color: rgba(0, 0, 0, 0.5);
            text-transform: uppercase;
        }

        table tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        table tr:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .button {
            padding: 8px 12px;
            margin: 0 5px 0 0;  /* Distanza tra i pulsanti */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            color: #fff;
            display: inline-block; /* Disporre i pulsanti in linea */
        }

        .view-button {
            background-color: #007bff;
        }

        .edit-button {
            background-color: #ffc107;
        }

        .delete-button {
            background-color: #dc3545;
        }

        .add-button {
            display: inline-block;
            background-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
        }

        .back-button {
            display: inline-block;
            background-color: #007bff;  /* Colore blu per il pulsante */
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            margin-top: 20px;
            color: #fff;
        }

        .back-button:hover {
            opacity: 0.9;
        }

        .button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gestione Progetti</h1>

        <!-- Pulsante per tornare alla home (index.html) -->
        <a href="index.html" class="back-button">Torna alla Pagina Home</a>

        <!-- Pulsante per aggiungere un nuovo progetto -->
        <a href="aggiungi_progetto.php" class="add-button">Crea Nuovo Progetto</a>

        <!-- Tabella con i progetti -->
        <?php if ($projects): ?>
            <table>
                <thead>
                    <tr>
                        <th>Nome Progetto</th>
                        <th>Descrizione</th>
                        <th>Azioni</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects as $project): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($project['nome']); ?></td>
                            <td><?php echo htmlspecialchars($project['descrizione']); ?></td>
                            <td>
                                <!-- Pulsanti azione -->
                                <a href="visualizza_attivita.php?id_progetto=<?php echo $project['id']; ?>" class="button view-button">Visualizza Attività</a>
                                <a href="modifica_progetto.php?id_progetto=<?php echo $project['id']; ?>" class="button edit-button">Modifica</a>
                                <a href="elimina_progetto.php?id_progetto=<?php echo $project['id']; ?>" class="button delete-button" onclick="return confirm('Sei sicuro di voler eliminare questo progetto?')">Elimina</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Nessun progetto trovato. Aggiungi un nuovo progetto utilizzando il pulsante sopra.</p>
        <?php endif; ?>
    </div>
</body>
</html>
