<?php
// Connessione al database
$conn = mysqli_connect("localhost", "root", "", "to_do_app"); // Cambia i parametri se necessario

// Controlla se la connessione è andata a buon fine
if (!$conn) {
    die("Connessione fallita: " . mysqli_connect_error());
}
?>
