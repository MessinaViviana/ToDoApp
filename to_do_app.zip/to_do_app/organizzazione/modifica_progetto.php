<?php
// Connessione al database
include('db.php');

// Recupera l'ID del progetto dalla query string
$id_progetto = $_GET['id_progetto'] ?? 0;

// Recupera le informazioni del progetto
$query_progetto = "SELECT * FROM progetti WHERE id = '$id_progetto'";
$result_progetto = mysqli_query($conn, $query_progetto);
$progetto = mysqli_fetch_assoc($result_progetto);

// Se non ci sono risultati, redirige
if (!$progetto) {
    header('Location: index.php');
    exit;
}

// Se il form è stato inviato, aggiorna il progetto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $descrizione = $_POST['descrizione'];

    // Query per aggiornare il progetto
    $query_update = "UPDATE progetti SET nome = '$nome', descrizione = '$descrizione' WHERE id = '$id_progetto'";
    
    if (mysqli_query($conn, $query_update)) {
        // Redirige al dettaglio del progetto
        header('Location: visualizza_attivita.php?id_progetto=' . $id_progetto);
        exit;
    } else {
        echo "Errore nell'aggiornamento del progetto: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifica Progetto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, textarea {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .back-button {
            display: inline-block;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            color: #fff;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Modifica Progetto</h1>

    <!-- Form per la modifica del progetto -->
    <form method="POST" action="">
        <label for="nome">Nome Progetto:</label>
        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($progetto['nome']); ?>" required>
        
        <label for="descrizione">Descrizione Progetto:</label>
        <textarea id="descrizione" name="descrizione" rows="4" required><?php echo htmlspecialchars($progetto['descrizione']); ?></textarea>
        
        <input type="submit" value="Aggiorna Progetto">
    </form>

    <a href="index.php" class="back-button">Torna alla lista dei progetti</a>
</div>
</body>
</html>
