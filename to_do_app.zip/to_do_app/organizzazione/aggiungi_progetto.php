<?php
// Connessione al database
include('db.php');

// Variabili per i dati del progetto
$nome = '';
$descrizione = '';

// Verifica se il form è stato inviato
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera i dati inviati dal form
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);
    $descrizione = mysqli_real_escape_string($conn, $_POST['descrizione']);

    // Query per inserire un nuovo progetto
    $query_insert = "INSERT INTO progetti (nome, descrizione) VALUES ('$nome', '$descrizione')";

    // Esegui la query
    if (mysqli_query($conn, $query_insert)) {
        echo "<p>Progetto creato con successo!</p>";
        echo "<a href='index.php' class='back-button'>Torna alla lista dei progetti</a>";
        exit;
    } else {
        echo "<p>Errore durante la creazione del progetto: " . mysqli_error($conn) . "</p>";
    }
}

// Chiudi la connessione al database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crea Nuovo Progetto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input, textarea {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        label {
            font-weight: bold;
        }

        .button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }

        .back-button {
            display: inline-block;
            background-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            margin-top: 20px;
            color: #fff;
        }

        .back-button:hover {
            opacity: 0.9;
        }

        .button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Crea Nuovo Progetto</h1>
    <!-- Form per inserire il progetto -->
    <form method="POST">
        <label for="nome">Nome Progetto:</label>
        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>

        <label for="descrizione">Descrizione Progetto:</label>
        <textarea id="descrizione" name="descrizione" required><?php echo htmlspecialchars($descrizione); ?></textarea>

        <button type="submit" class="button">Crea Progetto</button>
    </form>

    <a href="index.php" class="back-button">Torna alla lista dei progetti</a>
</div>

</body>
</html>
