<?php
// Connessione al database
include('db.php');

// Recupera l'ID dell'attività dalla query string
$id_attivita = $_GET['id_attivita'] ?? 0;

// Debug: Verifica l'ID attività
echo "ID Attività: " . $id_attivita . "<br>";

// Recupera le informazioni dell'attività
$query_attivita = "SELECT * FROM attivita WHERE id = '$id_attivita'";
$result_attivita = mysqli_query($conn, $query_attivita);

// Debug: Verifica se la query è stata eseguita correttamente
if ($result_attivita) {
    echo "Query eseguita correttamente.<br>";
} else {
    echo "Errore nella query: " . mysqli_error($conn) . "<br>";
}

$attivita = mysqli_fetch_assoc($result_attivita);

// Debug: Verifica se l'attività è stata trovata
if (!$attivita) {
    echo "<p>Attività non trovata.</p>";
    exit;
}

// Variabili per il salvataggio dei dati
$titolo = $attivita['titolo'];
$descrizione = $attivita['descrizione'];
$data_scadenza = $attivita['data_scadenza'];
$completato = $attivita['completato'];

// Salvataggio modifiche
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debug: Visualizza i dati inviati dal form
    echo "Dati inviati:<br>";
    var_dump($_POST);

    $titolo = mysqli_real_escape_string($conn, $_POST['titolo']);
    $descrizione = mysqli_real_escape_string($conn, $_POST['descrizione']);
    $data_scadenza = mysqli_real_escape_string($conn, $_POST['data_scadenza']);
    $completato = isset($_POST['completato']) ? 1 : 0;

    // Aggiorna l'attività nel database
    $query_update = "UPDATE attivita SET titolo = '$titolo', descrizione = '$descrizione', data_scadenza = '$data_scadenza', completato = '$completato' WHERE id = '$id_attivita'";
    
    if (mysqli_query($conn, $query_update)) {
        echo "<p>Attività aggiornata con successo!</p>";
        echo "<a href='visualizza_attivita.php?id_progetto=" . $_GET['id_progetto'] . "' class='back-button'>Torna alla lista delle attività</a>";
        exit;
    } else {
        echo "<p>Errore durante l'aggiornamento dell'attività: " . mysqli_error($conn) . "</p>";
    }
}

// Chiudi la connessione al database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifica Attività</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input, textarea {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        label {
            font-weight: bold;
        }

        .button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }

        .back-button {
            display: inline-block;
            background-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            margin-top: 20px;
            color: #fff;
        }

        .back-button:hover {
            opacity: 0.9;
        }

        .button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Modifica Attività</h1>
    <!-- Form per modificare l'attività -->
    <form method="POST">
        <label for="titolo">Titolo:</label>
        <input type="text" id="titolo" name="titolo" value="<?php echo htmlspecialchars($titolo); ?>" required>

        <label for="descrizione">Descrizione:</label>
        <textarea id="descrizione" name="descrizione" required><?php echo htmlspecialchars($descrizione); ?></textarea>

        <label for="data_scadenza">Data di Scadenza:</label>
        <input type="date" id="data_scadenza" name="data_scadenza" value="<?php echo htmlspecialchars($data_scadenza); ?>" required>

        <label for="completato">Completata:</label>
        <input type="checkbox" id="completato" name="completato" <?php echo $completato ? 'checked' : ''; ?>>

        <button type="submit" class="button">Salva Modifiche</button>
    </form>

    <a href="visualizza_attivita.php?id_progetto=<?php echo $_GET['id_progetto']; ?>" class="back-button">Torna alla lista delle attività</a>
</div>

</body>
</html>
